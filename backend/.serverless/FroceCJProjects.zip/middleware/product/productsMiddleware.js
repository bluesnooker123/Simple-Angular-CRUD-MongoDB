const chalk = require('chalk');
exports.productsMiddleWareValidation = (req, res, next) => {
  var errorMessage = '';
  if(req.body.productName === undefined || req.body.productName === '') {
    errorMessage += 'productName, ';
  } else if(req.body.type === undefined || req.body.type === '') {
    errorMessage += 'type, ';
  } else if(req.body.subtype === undefined || req.body.subtype === '') {
    errorMessage += 'subtype, ';
  } else if(req.body.sku === undefined || req.body.sku === '') {
    errorMessage += 'sku, ';
  } else if(req.body.startDate === undefined || req.body.startDate === '') {
    errorMessage += 'startdate, ';
  } else if(req.body.endDate === undefined || req.body.endDate === '') {
    errorMessage += 'enddate, ';
  } else if(req.body.description === undefined || req.body.description === '') {
    errorMessage += 'description, ';
  } else if(req.body.imageLocation === undefined || req.body.imageLocation === '') {
    errorMessage += 'imagelocation, ';
  } else if(req.body.taxCode === undefined || req.body.taxCode === '') {
    errorMessage += 'taxCode, '
  } else if(req.body.taxMode === undefined || req.body.taxMode === '') {
    errorMessage += 'taxMode'
  }
  if(errorMessage!=='') {
    res.status(400).send({
      status: 400,
      message: errorMessage + ' required'
    })
  } else {
    next();
  }
};


exports.productsUpdateMiddleWare = (req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Product Update ----------------"));
  const data = req.body;
  console.log(data);
  var errorMessage = '';
  if(req.body.productName === undefined || req.body.productName === '') {
    errorMessage += 'productName, ';
  } else if(req.body.type === undefined || req.body.type === '') {
    errorMessage += 'type, ';
  } else if(req.body.subtype === undefined || req.body.subtype === '') {
    errorMessage += 'subtype, ';
  } else if(req.body.sku === undefined || req.body.sku === '') {
    errorMessage += 'sku, ';
  } else if(req.body.description === undefined || req.body.description === '') {
    errorMessage += 'description, ';
  } else if(req.body.imageLocation === undefined || req.body.imageLocation === '') {
    errorMessage += 'imagelocation, ';
  } else if(req.body.taxCode === undefined || req.body.taxCode === '') {
    errorMessage += 'taxCode, '
  } else if(req.body.taxMode === undefined || req.body.taxMode === '') {
    errorMessage += 'taxMode'
  }
  if(errorMessage!=='') {
    res.status(400).send({
      status: 400,
      message: errorMessage + ' required'
    })
  } else {
    next();
  }

};
