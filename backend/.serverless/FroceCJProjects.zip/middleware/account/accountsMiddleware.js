const chalk = require('chalk');
var _this = this;
exports.accountCreateMiddleWare = (req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Account Create ----------------"));
  const data = req.body;
  //Middleware API Validation
  const isCompanyNameAvailable = () => {
     var result;
     if(data.companyName !== undefined) {
       result = true;
     } if(data.companyName !== '') {
       result = true;
     } if(data.companyName === undefined) {
       result = false;
     } if(data.companyName === '') {
       result = false;
     }
     return result;
  };

  const isAccountNumberAvailable = () => {
    var result;
    if(data.accountNo !== undefined) {
      result = true;
    } if(data.accountNo !== '') {
      result = true;
    } if(data.accountNo === undefined) {
      result = false;
    } if(data.accountNo === '') {
      result = false;
    }
    return result;
  };

  console.log(chalk.red("Company Available:", isCompanyNameAvailable()));
  console.log(chalk.red("Account Available:", isCompanyNameAvailable()));
  if(isCompanyNameAvailable() && isAccountNumberAvailable()) {
    next();
  }
  else if (!isCompanyNameAvailable() && isAccountNumberAvailable()){
      res.status(400).send({
        'message': 'Error! Company name required'
      })
  }
  else if (!isCompanyNameAvailable() && !isAccountNumberAvailable()){
    res.status(400).send({
      'message': 'Error! Company name and Account number required'
    })
  }
  else if (isCompanyNameAvailable() && !isAccountNumberAvailable()) {
    // Generate the account number (A-XXXXXXXXXXXX)
    // var companyName = req.body.companyName;
    var randomNumber = _this.randomIntFromInterval(1000000000, 9999999999);
    // companyName = companyName.replace(/\s/g , "-");
    req.body.accountNo = 'A-'+randomNumber;
    console.log("Request Account Number:", req.body.accountNo)
    next();
  }
};

exports.accountUpdateMiddleWare = (req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Account Update ----------------"));
  const data = req.body;
  console.log(data);
  next();
};


exports.randomIntFromInterval = (min, max) => { // min and max included
  return Math.floor(Math.random() * (max - min + 1) + min);
};

