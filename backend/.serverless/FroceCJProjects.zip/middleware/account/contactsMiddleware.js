const chalk = require('chalk');
var contactCategory = '';
var wrapObj = {};
var _this = this;


exports.contactFilterData = async(req, res, next) => {
   const data = req.body;
   if(data.contactCategory === 'shipping_contact_details') {
    contactCategory = 'shippingContactDetails';
    wrapObj['billingContactDetails'] = {};
    wrapObj['corporateContactDetails'] = {};
  } else if(data.contactCategory === 'billing_contact_details') {
    contactCategory = 'billingContactDetails';
    wrapObj['shippingContactDetails'] = {};
    wrapObj['corporateContactDetails'] = {};
  } else if(data.contactCategory === 'corporate_contact_details') {
    contactCategory = 'corporateContactDetails';
    wrapObj['billingContactDetails'] = {};
    wrapObj['shippingContactDetails'] = {};
  }
  // API Data Backend Validation Business Logic
  var isvalidatedData = await _this.apiContactDetailsValidation(req, res);

  if(isvalidatedData) {
    var result = await _this.wrapDataIntoObject(req, wrapObj);
    console.log(chalk.bgYellow("------------ Contact Details "+contactCategory+ " Added ------------"));
    console.log(result);
    req.body.filterResult = result;
    console.log(chalk.redBright("Account ObjectId:", data.accountObjectId));
    next();
  }
};



exports.wrapDataIntoObject = ((wrapReq, wrapContact) => {
  wrapContact.accountObjectId = wrapReq.body.accountObjectId;
  const contactDetailsSame = wrapReq.body.isContactDetails_SameforAll;
  const forAllContactDetails = ['billingContactDetails', 'shippingContactDetails', 'corporateContactDetails'];
  if(contactDetailsSame) {
    forAllContactDetails.forEach((data) => {
        wrapContact[data] = {};
        wrapContact[data].contactType = wrapReq.body.contactType;
        wrapContact[data].firstName = wrapReq.body.firstName;
        wrapContact[data].lastName = wrapReq.body.lastName;
        wrapContact[data].workEmail = wrapReq.body.workEmail;
        wrapContact[data].city = wrapReq.body.city;
        wrapContact[data].country = wrapReq.body.country;
        wrapContact[data].postalCode = wrapReq.body.postalCode;
        wrapContact[data].state = wrapReq.body.state;
        wrapContact[data].alternativeEmail = wrapReq.body.alternativeEmail;
        wrapContact[data].workPhone = wrapReq.body.workPhone;
        wrapContact[data].mobilePhone = wrapReq.body.mobilePhone;
        wrapContact[data].alternatePhone = wrapReq.body.alternatePhone;
        wrapContact[data].contactId = wrapReq.body.contactId;
        wrapContact[data].address1 = wrapReq.body.address1;
        wrapContact[data].address2 = wrapReq.body.address2;
        wrapContact[data].fax = wrapReq.body.fax;
        wrapContact[data].contactAccountId = wrapReq.body.contactAccountId;
        wrapContact[data].contactCreationDate = wrapReq.body.contactCreationDate;
        wrapContact[data].contactLastUpdateDate = wrapReq.body.contactLastUpdateDate;
    });
  } else {
      wrapContact[contactCategory] = {};
      wrapContact[contactCategory].contactType = wrapReq.body.contactType;
      wrapContact[contactCategory].firstName = wrapReq.body.firstName;
      wrapContact[contactCategory].lastName = wrapReq.body.lastName;
      wrapContact[contactCategory].workEmail = wrapReq.body.workEmail;
      wrapContact[contactCategory].city = wrapReq.body.city;
      wrapContact[contactCategory].country = wrapReq.body.country;
      wrapContact[contactCategory].postalCode = wrapReq.body.postalCode;
      wrapContact[contactCategory].state = wrapReq.body.state;
      wrapContact[contactCategory].alternativeEmail = wrapReq.body.alternativeEmail;
      wrapContact[contactCategory].workPhone = wrapReq.body.workPhone;
      wrapContact[contactCategory].mobilePhone = wrapReq.body.mobilePhone;
      wrapContact[contactCategory].alternatePhone = wrapReq.body.alternatePhone;
      wrapContact[contactCategory].contactId = wrapReq.body.contactId;
      wrapContact[contactCategory].address1 = wrapReq.body.address1;
      wrapContact[contactCategory].address2 = wrapReq.body.address2;
      wrapContact[contactCategory].fax = wrapReq.body.fax;
      wrapContact[contactCategory].contactAccountId = wrapReq.body.contactAccountId;
      wrapContact[contactCategory].contactCreationDate = wrapReq.body.contactCreationDate;
      wrapContact[contactCategory].contactLastUpdateDate = wrapReq.body.contactLastUpdateDate;
    }
    return wrapContact;
});


exports.apiContactDetailsValidation = ((req, res) => {
  var isStatus = false;
  var accountObjectId = req.body.accountObjectId;
  var errText = '';
  if(accountObjectId === '') {
    isStatus = false;
    console.log(chalk.red("AccountObjectId is missiong in contact details!!"));
    res.status(400).send({
      message: 'AccountObject Id is missing, Make Sure You have filled all the account details first to the respective contact information !!'
    })
  } else {
      if(req.body.contactType === '') {
        errText += 'Contact Type, ';
      } if(req.body.workEmail === '') {
        errText += 'Work Email, ';
      } if(req.body.country === '') {
        errText += 'Country, ';
      } if(req.body.firstName === '') {
        errText += 'Firstname, ';
      } if(req.body.lastName === '') {
        errText += 'Lastname, ';
      } if(req.body.state === '') {
        errText += 'State, ';
      } if(req.body.postalCode === '') {
        errText += 'postalCode, ';
      } if(req.body.address1 === '') {
        errText += 'Address, ';
      }

      if(errText !== '') {
        errText += ' is required !!!'
        isStatus = false;
        res.status(400).send({
          message: errText
        });
      } else if(errText === '') {
        isStatus = true;
        console.log(chalk.red("Everything is good in contact details!!"));
      }
  }
  return isStatus;
});
