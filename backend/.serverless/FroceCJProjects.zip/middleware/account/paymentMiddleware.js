const chalk = require('chalk');
const mongoose = require('mongoose');
const config = require('config');
const stripePublicKey = config.paymentGetway.stripe.publicKey; //This is only for generating token
const stripeSecretKey = config.paymentGetway.stripe.secretKey; //This is for generating token and making charge from customer
const stripe = require('stripe')(stripeSecretKey);

require('../../models/paymenttoken.js');
const Payment_token = mongoose.model('Payment_token_details');

var _this = this;
var wrapObj = {};

exports.verifyPaymentInformation = async(req, res, next) => {
  wrapObj['accountId'] = req.body.accountObjectId;
  wrapObj['cardNumber'] = req.body.cardNumber;
  wrapObj['expireIn'] = req.body.expiresIn;
  wrapObj['cvv'] = req.body.cvvCode;

  console.log(chalk.bgYellowBright("Is card details provided ? ---> "+req.body.isCardDetailsProvided));
  // If card details provided then validate API data or else not
  if(req.body.isCardDetailsProvided) {
    const isValidate = await _this.validateAPIData(res, wrapObj);
    if(isValidate) {
       // Stripe Verification went here if all clear then pass next
       console.log(chalk.bgYellowBright("I am stripe payment getway validating card !!\n\n"));
       console.log(chalk.bgYellow("First step -> Generate token for card !!\n"));
       const isTokenGenerated = await _this.generateToken(req, res);
       if(isTokenGenerated.status) {
          var wrapData = await _this.wrapingUpDataIntoObjects(req, isTokenGenerated);
          // If data exists into database then update or else insert ->
          Payment_token.findOne({'accountObjectId': wrapData.accountObjectId}, async( err, paymentdata) => {
            if (paymentdata!==null) {
              if(paymentdata.carddetails.length > 0) {
                paymentdata.carddetails.push(wrapData.carddetails);
                var paymentSave = new Payment_token(paymentdata);
                paymentSave.save().then(async(data) => {
                  console.log(chalk.bgYellow("Second Step - Payment token Details Saved to the database !!\n\n"));
                  var chargeCustomer = await _this.chargeCustomerViaToken(wrapData);
                  if(chargeCustomer.status) {
                    req.body.paymentDetailsInfo = {
                      viaStripe: chargeCustomer.data
                    }
                    console.log(chalk.bgYellow("Forth Step - Trasaction made !!\n\n"));
                    next();
                  } else {
                    res.status(200).send({
                      message: chargeCustomer.message,
                    })
                  }
                }).catch(err => {
                   console.log(chalk.red('Third Step - Error, Payment failed !!'));
                   res.send({
                    err: err,
                    status: 400,
                    message: 'Third Step - Error, Payment failed !!'
                  })
                });
              }
            } else {
              var paymentSave = new Payment_token(wrapData);
              paymentSave.save().then(async(data) => {
                console.log(chalk.bgYellow("Second Step - Payment token Details Saved to the database !!\n\n"));
                var chargeCustomer = await _this.chargeCustomerViaToken(wrapData);
                if(chargeCustomer.status) {
                  req.body.paymentDetailsInfo = {
                    viaStripe: chargeCustomer.data
                  }
                  next();
                } else {
                  res.status(200).send({
                    message: chargeCustomer.message,
                  })
                }
              }).catch(err => {
                console.log(chalk.red('Third Step - Error, Payment failed !!'))
                res.send({
                  err: err,
                  status: 400,
                  message: 'Third Step - Error, Payment failed !!'
                })
              });
            }
          });
       } else {
          console.log(chalk.bgRed("First Step, Failed! Token not generated."));
          res.status(400).send({
             message: 'Card is invalid !!'
          });
       }
    }
  } else {
    next();
  }


};

// Create a customer inside stripe payment getway
// Create a customer inside stripe payment getway


// Wrapping up data into array
exports.wrapingUpDataIntoObjects = async(req, isTokenGenerated) => {
  var result = await req.body;
  var changeData = await isTokenGenerated;
  changeData.data.card.address_country = req.body.country;
  changeData.data.card.address_state = req.body.state;
  changeData.data.card.address_city = req.body.city;
  changeData.data.card.address_zip = req.body.pincode;
  changeData.data.card.name = req.body.cardHolderName;
  changeData.data.card.country = req.body.country;
  changeData.data.card.address_line1 = req.body.address1;
  changeData.data.card.address_line2 = req.body.address2;

  var params = {
    accountObjectId: result.accountObjectId,
    carddetails: changeData.data
  }
  return params;

}
// Wrapping up data into array


// Stripe Step 1 - Create token
exports.generateToken = async (req, res) => {
    const cardNumber = req.body.cardNumber.replace(/\s/g, '');;
    const expireIn = req.body.expiresIn.split('/');
    const cvc = req.body.cvvCode;
    var param = {};
    param.card = {
        number: cardNumber,
        exp_month: parseInt(expireIn[0]),
        exp_year:parseInt(expireIn[1]),
        cvc: cvc
    }
    return new Promise((resolve, reject) => {
      stripe.tokens.create(param, function (err,token) {
        if(err) {
          console.log(chalk.red("err: "+err));
          status = false;
          reject({
            status: false,
            message: err
          });
        } if(token) {
            console.log(chalk.green("success: "+JSON.stringify(token, null, 2)));
            resolve({
              status: true,
              message: 'Token generated !!',
              data: token,
            });
        } else {
            console.log(chalk.red("Something wrong"));
            reject({
              status: false,
              message: err
            })
          }
      });
  });
}

// Stripe Step - 2 : Charge customer through the token for validating card
// If he/she is a first user, need to verify his mobile number https://dashboard.stripe.com/dashboard
// Stripe1 Docs - https://stripe.com/docs/testing
// Stripe2 Docs - https://stripe.com/docs/payments/integration-builder
// Stripe3 Docs - https://stripe.com/docs/payments
// Stripe4 Docs - https://stripe.com/docs/payments/accept-a-payment#web-collect-card-details
// Stripe5 Docs - https://stripe.com/docs/testing -- > List of card for testing

exports.chargeCustomerViaToken = (wrapData) => {
  console.log(chalk.bgYellow("Third Step - Trasanction process from customer account !!\n\n"));
  var param = {
    amount: '100',
    currency: 'inr',
    description:'Stripe payment method',
    source: wrapData.carddetails.id
  };
  return new Promise((resolve, reject) => {
    stripe.charges.create(param, function (err,charge) {
      if(err) {
        console.log(chalk.red("err: "+err));
        reject({
          status: false,
          message: err
        });
      } if(charge) {
          console.log(chalk.green("success: "+JSON.stringify(charge, null, 2)));
          resolve({
            status: true,
            message: 'Charge made, card validate !!',
            data: charge,
          });
      } else {
          console.log(chalk.red("Something wrong"));
          reject({
            status: false,
            message: 'Something wrong !!'
          })
        }
    })
  })
};


// Validated API Data
exports.validateAPIData = async(res, wrapObj) => {
  var isStatus = false;
  var errText = '';
  if(wrapObj.accountId === '' || wrapObj.accountId === undefined) {
    console.log(chalk.bgRedBright("Invalid payment, Account Id missing !!!"));
    isStatus = false;
    res.status(400).send({
      message: 'Account Id is missing !!'
    })
  } else {
      if(wrapObj.cardNumber === '' || wrapObj.cardNumber === undefined) {
          errText += 'CardNumber , ';
      } if(wrapObj.expireIn === '' || wrapObj.expireIn === undefined) {
          errText += 'expiresIn , ';
      } if(wrapObj.cvv === '' || wrapObj.cvv === undefined) {
          errText += 'cvv , ';
      }

      if(errText !== '') {
        errText += ' is required !!!'
        isStatus = false;
        res.status(400).send({
          message: errText
        });
      } else if(errText === '') {
        isStatus = true;
        console.log(chalk.red("Everything is good in payment details!!"));
      }
  }
  return isStatus;
};
