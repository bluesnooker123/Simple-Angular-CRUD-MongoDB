const chalk = require('chalk');

exports.billingInformationMiddleWare = (req, res, next) => {
   if(req.body.accountObjectId === undefined || req.body.accountObjectId === '') {
     console.log(chalk.red('AccountID is missing !! Bill information cant submit without accountId'));
     res.send({
       status: 400,
       message: 'Account Id is missing !!'
     });
   } else {
     next();
   }
};
