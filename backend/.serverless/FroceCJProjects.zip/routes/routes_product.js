const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

app.use(bodyParser.json());

app.use(cors());

// Authentication of user
const authentication = require('../authentication/auth');

// Controller
const configCtrl = require('../controllers/configCtrl');
const productDetails = require('../controllers/product/productCtrl');
const productPriceGroup = require('../controllers/product/priceGroupCtrl');
const productPriceChargesGroup = require('../controllers/product/priceGroupChargeCtrl');

// MiddleWare
const productMiddleWare = require('../middleware/product/productsMiddleware');

// Products Config API
app.get('/product/config/details', authentication.authUser, (req, res, next) => {
  configCtrl.productConfigDetails(req, res);
});

// Products API Create
app.post('/product/create', [authentication.authUser, productMiddleWare.productsMiddleWareValidation], (req, res, next) => {
  productDetails.ProductCreate(req, res);
});

// Products API Create
app.post('/product/image/upload', [authentication.authUser], (req, res, next) => {
  productDetails.imageCreate(req, res);
});

// Products API Update
app.post('/product/update/:id', [authentication.authUser, productMiddleWare.productsUpdateMiddleWare], (req, res, next) => {
  productDetails.productUpdate(req, res);
});

// Products API List
app.get('/product/list', authentication.authUser, (req, res, next) => {
  productDetails.productList(req, res);
});

// Products API ListById
app.get('/product/list/:id', authentication.authUser, (req, res, next) => {
  productDetails.productListById(req, res);
});

// Products API Delete
app.get('/product/delete/:id', authentication.authUser, (req, res, next) => {
  productDetails.productDeleteById(req, res);
});

// Products Create New PriceGroup API
app.post('/product/pricegroup/information', [authentication.authUser], (req, res, next) => {
  productPriceGroup.priceGroup(req, res);
});

app.get('/product/pricegroup/information/:id', authentication.authUser, (req, res, next) => {
  productPriceGroup.getPriceGroupInformation(req, res);
});

// Products Create New PriceGroup Charges Onetime API
app.post('/product/pricegroup/charges/onetime/information', [authentication.authUser], (req, res, next) => {
  productPriceChargesGroup.chargesGroupOneTime(req, res);
});

// Products Create New PriceGroup Charges Subscription API
app.post('/product/pricegroup/charges/subscription/information', [authentication.authUser], (req, res, next) => {
  productPriceChargesGroup.chargesGroupSubscription(req, res);
});

// Products Create New PriceGroup Charges Usages API
app.post('/product/pricegroup/charges/usages/information', [authentication.authUser], (req, res, next) => {
  productPriceChargesGroup.chargesGroupUsage(req, res);
});

// Products Create New PriceGroup Charges Information API
app.post('/product/pricegroup/charges/information', authentication.authUser, (req, res, next) => {
  productPriceChargesGroup.getPriceGroupChargesInformation(req, res);
});

module.exports = app;
