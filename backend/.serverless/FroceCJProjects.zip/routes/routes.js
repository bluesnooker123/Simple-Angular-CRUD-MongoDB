const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

app.use(bodyParser.json());

app.use(cors());

// Authentication of user
const authentication = require('../authentication/auth');

// Controller
const endUser = require('../controllers/login-registration/endUserCtrl');

// Sample API testing
app.get('/', (req, res) => {
  res.send({
     status:200,
     message:'App is working fine!'
  });
});

// Register users
app.post('/users/register', (req, res, next) => {
  endUser.registration(req, res);
});

// Login users
app.post('/users/login',  (req, res, next) => {
  endUser.login(req, res);
});

// Add users
app.post('/users/add', authentication.authUser, (req, res, next) => {
  endUser.add(req, res);
});

// Get All User
app.get('/users', authentication.authUser, (req, res, next) => {
  endUser.getUsers(req, res);
});

// Get specific Users
app.get('/users/:id', authentication.authUser, (req, res, next) => {
  endUser.getEachUser(req, res);
});

// User Update
app.post('/users/update/:id', authentication.authUser, (req, res, next) => {
  endUser.userUpdate(req, res);
});

// User Delete
app.get('/users/delete/:id', authentication.authUser, (req, res, next) => {
  endUser.userDelete(req, res);
});

module.exports = app;
