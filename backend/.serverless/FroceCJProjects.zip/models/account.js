const mongoose = require('mongoose');

var Schema = mongoose.Schema;

var accountschema = new mongoose.Schema({
  accountNo: { type: String},
  salesResp:{ type: String },
  companyName: { type: String},
  companyType: { type: String},
  creationDate: { type: Date},
  lastUpdateDate: {type: Date},
  creditRating: { type: String},
  crmId: { type: String},
  industryType: { type: String},
  notes: { type: String},
  accountId: { type: String, default: ''},
  corporateContactId: { type: String, default: ''},
  paymentMethodId: { type: String, default: ''},
  billingContactId: { type: String, default: ''},
  shippingContactId:{ type: String, default: '' },
  status:{ type: String, default: 'Open' },

  // status:{ type: String, default: 'Open' },
  // creationdate:{ type: Date, default: Date.now }
});

var Account = mongoose.model('Account', accountschema);
module.exports = Account;
