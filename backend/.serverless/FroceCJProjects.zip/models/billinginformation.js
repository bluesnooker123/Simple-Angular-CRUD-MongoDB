const mongoose = require('mongoose');

var billinginfo = new mongoose.Schema({
  accountObjectId: {
    type: String,
    default: '',
    trim: true
  },
  "billingcurrency_name": {
    type: String,
    trim:true
  },
  billingcurrency_code:  {
    type: String,
    trim:true
  },
  billday: {
    type: String,
    trim:true
  },
  billingbatch:  {
    type: String,
    trim:true
  },
  invoicelanguage:  {
    type: String,
    trim:true
  },
  invoicetemplate:  {
    type: String,
    trim:true
  },
  deliverytype:  {
    type: String,
    trim:true
  },
  paymentafter:  {
    type: String,
    trim:true
  },
});

var Billinginformation = mongoose.model('Billinginformation', billinginfo);
module.exports = Billinginformation;
