const mongoose = require('mongoose');

var priceGroupCharge = new mongoose.Schema({
  productObjectId: { type: String, default: ''},
  pricegroupName: { type: String, default: ''},
  chargeArray: {
    onetime: { type: Array },
    subscription: { type: Array },
    usages: { type: Array },
  },
  // name: { type: String, default: ''},
  // description: { type: String, default: ''},
  // type: { type: String, default: ''},
  // chargeAmount: { type: String, default: ''},
  // chargeDiscount: { type: String, default: ''},
  // chargeDiscountAmount: { type: String, default: ''},
  // voucher: { type: String, default: ''},
  // coupon: { type: String, default: ''},
  // startDate: { type: Date},
  // endDate: { type: Date},
  // creationdate:{ type: Date, default: Date.now },
  // updationdate:{ type: Date, default: Date.now },
});

var priceGroupCharge = mongoose.model('priceGroupCharge', priceGroupCharge);
module.exports = priceGroupCharge;
