const mongoose = require('mongoose');

var productschema = new mongoose.Schema({
  productName: { type: String, default: ''},
  type: { type: String, default: ''},
  subtype: { type: String, default: ''},
  sku: { type: String, default: ''},
  startDate: { type: Date},
  endDate: { type: Date},
  description: { type: String, default: ''},
  imageLocation: { type: String, default: ''},
  taxCode: { type: String, default: ''},
  taxMode:{ type: String, default: '' },
  taxAble:{ type: String, default: '' },
  status: { type: String, default: true },
  version:{ type: Number, default: 1 },
  creationdate:{ type: Date, default: Date.now },
  updationdate:{ type: Date, default: Date.now },
});

var Product = mongoose.model('Product', productschema);
module.exports = Product;
