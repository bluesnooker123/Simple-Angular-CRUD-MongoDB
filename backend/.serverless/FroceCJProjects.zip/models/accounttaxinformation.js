const mongoose = require('mongoose');

var accountTaxInformation = new mongoose.Schema({
  accountObjectId: {
    type: String,
    trim: true
  },
  taxExemption: {
    type: String,
    default: 'no'
  },
  certificateNo: {
    type: String,
    default: ''
  },
  certificateType: {
    type: String,
    default: ''
  },
  issueBy: {
    type: String,
    default: ''
  },
  refCode: {
    type: String,
    default: ''
  },
  vatId: {
    type: String,
    default: ''
  },
  notes: {
    type: String,
    default: ''
  }
});

var Accounttaxinformation = mongoose.model('Accounttaxinformation', accountTaxInformation);
module.exports = Accounttaxinformation;
