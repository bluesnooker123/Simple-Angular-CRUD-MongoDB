const mongoose = require('mongoose');

var paymenttoken = new mongoose.Schema({
    accountObjectId: {
      type: String,
      default: '',
      trim: true
    },
    carddetails: { type: Array }
});

var Payment_token_details = mongoose.model('Payment_token_details', paymenttoken);
module.exports = Payment_token_details;
