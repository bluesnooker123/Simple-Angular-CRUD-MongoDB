const mongoose = require('mongoose');

var payment = new mongoose.Schema({
    accountObjectId: {
      type: String,
      default: '',
      trim: true
    },
    isDefaultCard: { type: Boolean },
    isCardDetailsProvided: { type: Boolean, default: false },
    paymentGetway: { type: String, default: '' },
    paymentType: { type: String, default: '' },
    cardHolderName: { type: String, default: '' },
    cardNumber: { type: String, default: ''},
    expiresIn: { type: String, default: ''},
    cvvCode: { type: String, default: ''},
    country: { type: String, default: '' },
    state: { type: String, default: '' },
    city: { type: String, default: '' },
    address1: { type: String, default: '' },
    address2: { type: String, default: '' },
    pincode: { type: String, default: '' },
    transactiondetails_madeby_customer: { type: Array },
    paymentCreationDate: { type: Date},
    paymentUpdationDate: { type: Date},
    paymentDetailsInfo: {
      viaStripe: {type: Array}
    }
});

var Payment = mongoose.model('Payment', payment);
module.exports = Payment;
