const mongoose = require('mongoose');

var pricegroupschema = new mongoose.Schema({
  productObjectId: { type: String, default: ''},
  name: { type: String, default: ''},
  startDate: { type: Date},
  endDate: { type: Date},
  description: { type: String, default: ''},
  enableCharge: { type: Boolean, default: false},
  version:{ type: Number, default: 1 },
  creationdate:{ type: Date, default: Date.now },
  updationdate:{ type: Date, default: Date.now },
  priceGroup: { type: Array }
});

var Pricegroup = mongoose.model('Pricegroup', pricegroupschema);
module.exports = Pricegroup;
