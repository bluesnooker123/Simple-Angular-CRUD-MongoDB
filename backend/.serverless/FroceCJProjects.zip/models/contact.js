const mongoose = require('mongoose');

var contactschema = new mongoose.Schema({
  accountObjectId: {
    type: String,
    trim: true
  },
  shippingContactDetails: {
    contactType: {
      type: String,
      default: '',
      trim: true,
    },
    firstName: { type: String, default: '' },
    lastName: { type: String, default: '' },
    workEmail: {
      type: String,
      default: '',
      trim: true
    },
    country: {
      type: String,
      default: '',
      trim: true
    },
    state: {
      type: String,
      default: '',
      trim: true
    },
    city: {
      type: String,
      default: '',
      trim: true
    },
    alternativeEmail: {
      type: String,
      default: '',
    },
    postalCode: {
      type: String,
      default: ''
    },
    workPhone: {
      type: String,
      default: '',
    },
    mobilePhone: {
      type: String,
      default: '',
    },
    alternatePhone: {
      type: String,
      default: '',
    },
    contactId: {
      type: String,
      default: '',
    },
    address1: {
      type: String,
      default: '',
      trim: true
    },
    address2: {
      type: String,
      default: '',
      trim: true
    },
    fax: {
      type: String,
      default: '',
      trim: true
    },
    contactAccountId: {
      type: String,
      default: '',
      trim: true
    },
    contactCreationDate: {
      type: Date,
      default: '',
      trim: true
    },
    contactLastUpdateDate: {
      type: Date,
      default: '',
      trim: true
    }
  },
  billingContactDetails: {
    contactType: {
      type: String,
      default: '',
      trim: true,
    },
    firstName: { type: String, default: '' },
    lastName: { type: String, default: '' },
    workEmail: {
      type: String,
      default: '',
      trim: true
    },
    country: {
      type: String,
      default: '',
      trim: true
    },
    state: {
      type: String,
      default: '',
      trim: true
    },
    city: {
      type: String,
      default: '',
      trim: true
    },
    alternativeEmail: {
      type: String,
      default: '',
    },
    postalCode: {
      type: String,
      default: ''
    },
    workPhone: {
      type: String,
      default: '',
    },
    mobilePhone: {
      type: String,
      default: '',
    },
    alternatePhone: {
      type: String,
      default: '',
    },
    contactId: {
      type: String,
      default: '',
    },
    address1: {
      type: String,
      default: '',
      trim: true
    },
    address2: {
      type: String,
      default: '',
      trim: true
    },
    fax: {
      type: String,
      default: '',
      trim: true
    },
    contactAccountId: {
      type: String,
      default: '',
      trim: true
    },
    contactCreationDate: {
      type: Date,
      default: '',
      trim: true
    },
    contactLastUpdateDate: {
      type: Date,
      default: '',
      trim: true
    }
  },
  corporateContactDetails: {
    contactType: {
      type: String,
      default: '',
      trim: true,
    },
    firstName: { type: String, default: '' },
    lastName: { type: String, default: '' },
    workEmail: {
      type: String,
      default: '',
      trim: true
    },
    country: {
      type: String,
      default: '',
      trim: true
    },
    state: {
      type: String,
      default: '',
      trim: true
    },
    city: {
      type: String,
      default: '',
      trim: true
    },
    alternativeEmail: {
      type: String,
      default: '',
    },
    postalCode: {
      type: String,
      default: ''
    },
    workPhone: {
      type: String,
      default: '',
    },
    mobilePhone: {
      type: String,
      default: '',
    },
    alternatePhone: {
      type: String,
      default: '',
    },
    contactId: {
      type: String,
      default: '',
    },
    address1: {
      type: String,
      default: '',
      trim: true
    },
    address2: {
      type: String,
      default: '',
      trim: true
    },
    fax: {
      type: String,
      default: '',
      trim: true
    },
    contactAccountId: {
      type: String,
      default: '',
      trim: true
    },
    contactCreationDate: {
      type: Date,
      default: '',
      trim: true
    },
    contactLastUpdateDate: {
      type: Date,
      default: '',
      trim: true
    }
  }
});

var Contact = mongoose.model('Contact', contactschema);
module.exports = Contact;
