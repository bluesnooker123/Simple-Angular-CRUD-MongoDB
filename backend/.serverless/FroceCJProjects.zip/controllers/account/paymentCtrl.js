const mongoose = require('mongoose');
require('../../models/payment.js');
const Payment = mongoose.model('Payment');
const chalk = require('chalk');

// Save Payment Details on Respective Account
exports.verifyPayment = (req, res, next) => {
  Payment.findOne({'accountObjectId': req.body.accountObjectId}, async( err, paymentdata) => {
    if (paymentdata!==null) {
      // Save the list of payment details made till now from the customer end
      // Bussiness logic if its recent default card then show open in the collection or else went to inside array
      var allDetails = paymentdata;

      if(req.body.isCardDetailsProvided) {
        allDetails.paymentDetailsInfo.viaStripe.push(req.body.paymentDetailsInfo.viaStripe); //Only for stripe
        // allDetails.transactiondetails_madeby_customer.push(req.body.transactiondetails_madeby_customer);
      }


      var custPaymentDetailsInfo = allDetails.transactiondetails_madeby_customer;
      var isFound = false;
      var isItDefaultCard = req.body.transactiondetails_madeby_customer.isDefaultCard;

      // DefaultCard Bussiness logic comes here
      if(isItDefaultCard) {
        for(var i=0;i<custPaymentDetailsInfo.length;i++) {
          custPaymentDetailsInfo[i].isDefaultCard = false;
        }
      }
      // DefaultCard Bussiness logic ends here

      for(var i=0;i<custPaymentDetailsInfo.length;i++) {
        if(custPaymentDetailsInfo[i].paymentNo === req.body.transactiondetails_madeby_customer.paymentNo) {
          custPaymentDetailsInfo[i].cardHolderName = req.body.transactiondetails_madeby_customer.cardHolderName;
          custPaymentDetailsInfo[i].isDefaultCard = req.body.transactiondetails_madeby_customer.isDefaultCard;
          custPaymentDetailsInfo[i].country = req.body.transactiondetails_madeby_customer.country;
          custPaymentDetailsInfo[i].state = req.body.transactiondetails_madeby_customer.state;
          custPaymentDetailsInfo[i].city = req.body.transactiondetails_madeby_customer.city;
          custPaymentDetailsInfo[i].address1 = req.body.transactiondetails_madeby_customer.address1;
          custPaymentDetailsInfo[i].address2 = req.body.transactiondetails_madeby_customer.address2;
          custPaymentDetailsInfo[i].pincode = req.body.transactiondetails_madeby_customer.pincode;
          custPaymentDetailsInfo[i].paymentType = req.body.transactiondetails_madeby_customer.paymentType;
          custPaymentDetailsInfo[i].cardNumber = req.body.transactiondetails_madeby_customer.cardNumber;
          custPaymentDetailsInfo[i].expiresIn = req.body.transactiondetails_madeby_customer.expiresIn;
          custPaymentDetailsInfo[i].cvvCode = req.body.transactiondetails_madeby_customer.cvvCode;
          custPaymentDetailsInfo[i].paymentGetway = req.body.transactiondetails_madeby_customer.paymentGetway;
          isFound = true;
        }
      }
      allDetails.transactiondetails_madeby_customer = custPaymentDetailsInfo; //store here
      if(!isFound) { //then its a new record
        var findLength = allDetails.transactiondetails_madeby_customer.length;
        req.body.transactiondetails_madeby_customer.paymentNo = findLength+1;
        allDetails.transactiondetails_madeby_customer.push(req.body.transactiondetails_madeby_customer);
      }

      // Default card Logic Here
      if(isItDefaultCard) {
        allDetails.isCardDetailsProvided = req.body.isCardDetailsProvided;
        allDetails.paymentGetway = req.body.paymentGetway;
        allDetails.paymentType = req.body.paymentType;
        allDetails.cardHolderName = req.body.cardHolderName;
        allDetails.cardNumber = req.body.cardNumber;
        allDetails.expiresIn = req.body.expiresIn;
        allDetails.cvvCode = req.body.cvvCode;
        allDetails.country = req.body.country;
        allDetails.city = req.body.city;
        allDetails.address1 = req.body.address1;
        allDetails.address2 = req.body.address2;
        allDetails.pincode = req.body.pincode;
        allDetails.isDefaultCard = req.body.isDefaultCard;

      }




      allDetails.paymentUpdationDate = new Date();


      var payment = new Payment(allDetails);
      console.log(chalk.bgYellow("Fifth Step - Trasaction details save into database !!\n\n"));
      payment.save().then(payment => {
        console.log(chalk.green(payment));
        res.json({
          'status': 200,
          'message': 'Transaction done, Card Successfully verified !!!',
        });
      }).catch(err => {
        res.send({
          message: 'Transaction failed !!',
          status: 400,
          error: err
        });
      });
    } else {
      req.body.transactiondetails_madeby_customer.paymentNo = req.body.transactiondetails_madeby_customer.paymentNo === undefined ? 1 : req.body.transactiondetails_madeby_customer.paymentNo;
      var payment = new Payment(req.body);
      console.log(chalk.bgYellow("Fifth Step - Trasaction details and save into database !!\n\n"));
      payment.save().then(payment => {
        console.log(chalk.green(payment));
        res.json({
          'status': 200,
          'message': 'Transaction done, Card Successfully verified !!!',
        });
      }).catch(err => {
        res.send({
          message: 'Transaction failed !!',
          status: 400,
          error: err
        });
      });
    }
  });
};

exports.customerDefaultCardLogic = (req, res, next) => {

}


exports.getPaymentInformation = async(req, res, next) => {
  Payment.findOne({'accountObjectId': req.params.id}, async( err, paymentInfo) => {
    if (paymentInfo!==null) {
       res.send({
         status:200,
         data: paymentInfo,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: paymentInfo,
        message: 'no record found!!'
      });
    }
  })
};
