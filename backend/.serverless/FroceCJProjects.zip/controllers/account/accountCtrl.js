const mongoose = require('mongoose');
require('../../models/account.js');
const Account = mongoose.model('Account');

// Account Create
exports.accountCreate = (req, res, next) => {
  console.log(req.body);
  var account = new Account(req.body);
  account.save()
    .then(account => {
      res.status(200).json({
        'message': 'Added Successfully',
        'accountId': account._id
      });
    })
    .catch(err => {
      res.status(400).send('Failed to create new record');
    });
};

//Account Update
exports.accountUpdate = (req, res, next) => {
  Account.findById(req.params.id, ( err, account) => {
    if (!account)
      return onErrorResumeNext(new Error('Could not load document'));
    else  {
      account.companyName = req.body.companyName;
      account.accountNo = req.body.accountNo;
      account.crmId = req.body.crmId;
      account.status  = req.body.status;
      account.companyType = req.body.companyType;

      account.industryType = req.body.industryType;
      account.companyType = req.body.companyType;
      account.creditRating = req.body.creditRating;
      account.creationDate = req.body.creationDate;

      account.notes = req.body.notes;
      account.salesResp = req.body.salesResp;
      account.lastUpdateDate = req.body.lastUpdateDate;
      account.save().then( account => {
          res.json('Update Done')
      }).catch(err => {
          res.status(400).send('Update Failed');
      });
    }
  });
};

// Account List
exports.accountList = (req, res, next) => {
  Account.find((err,account)=> {
    if (err)
       console.log(err)
    else
      res.status(200).json(account);
  });
}

// Account List By Id
exports.accountListById = (req, res, next) => {
  Account.findById(req.params.id, (err, account) => {
    if (err)
      console.log(err)
    else
      res.json(account);
  });
}

// Account Delete By Id
exports.accountDeleteById = (req, res, next) => {
  Account.findByIdAndRemove({_id: req.params.id}, (err, account) => {
    if (err)
      res.json(err);
    else
      res.json('Remove sucessfully');
  });
}

