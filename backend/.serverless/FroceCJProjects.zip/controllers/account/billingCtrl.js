const mongoose = require('mongoose');
const chalk = require('chalk');
require('../../models/billinginformation');

const Billinginformation = mongoose.model('Billinginformation');


exports.billingInformation = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Bill Information Submited ----------------"));
  console.log(req.body);
  Billinginformation.findOne({'accountObjectId': req.body.accountObjectId}, async( err, billInfo) => {
      if (billInfo!==null) {
        billInfo.billingcurrency_name = req.body.billingcurrency_name;
        billInfo.billingcurrency_code = req.body.billingcurrency_code;
        billInfo.billday  = req.body.billday;
        billInfo.billingbatch = req.body.billingbatch;
        billInfo.invoicelanguage = req.body.invoicelanguage;
        billInfo.invoicetemplate = req.body.invoicetemplate;
        billInfo.deliverytype = req.body.deliverytype;
        billInfo.paymentafter = req.body.paymentafter;

        var billInfoSave = new Billinginformation(billInfo);

        billInfoSave.save().then(billInfo => {
          res.send({
            message: 'Bill Information Updated !!',
            status: 200,
            data: billInfo
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });
      } else if(!err && billInfo===null) { //Its a new record
        console.log(chalk.red("Bill Information - Its a new record!!"));
        var billInfoSave = new Billinginformation(req.body);
        billInfoSave.save().then(billInfo => {
          res.send({
            message: 'Bill Information Saved !!',
            status: 200,
            data: billInfo
          })
        }).catch(err => {
          res.send({
            message: 'Bill information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update bill information !!'
        })
      }
  });
}

exports.getBillingInformation = async(req, res, next) => {
  Billinginformation.findOne({'accountObjectId': req.params.id}, async( err, billInfo) => {
    if (billInfo!==null) {
       res.send({
         status:200,
         data: billInfo,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: billInfo,
        message: 'no record found!!'
      });
    }
  })
};
