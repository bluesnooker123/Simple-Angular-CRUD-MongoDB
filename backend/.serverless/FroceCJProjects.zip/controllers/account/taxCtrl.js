const mongoose = require('mongoose');
const chalk = require('chalk');
require('../../models/accounttaxinformation.js');

const Accounttaxinformation = mongoose.model('Accounttaxinformation');


exports.taxInformation = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Tax Information Submited ----------------"));
  console.log(req.body);
  Accounttaxinformation.findOne({'accountObjectId': req.body.accountObjectId}, async( err, taxInfo) => {
      if (taxInfo!==null) {
        taxInfo.taxExemption = req.body.taxExemption;
        taxInfo.certificateNo = req.body.certificateNo;
        taxInfo.certificateType  = req.body.certificateType;
        taxInfo.issueBy = req.body.issueBy;
        taxInfo.refCode = req.body.refCode;
        taxInfo.vatId = req.body.vatId;
        taxInfo.notes = req.body.notes;

        var taxSave = new Accounttaxinformation(taxInfo);

        taxSave.save().then(taxInfo => {
          res.send({
            message: 'Tax Information Updated !!',
            status: 200,
            data: taxInfo
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });
      } else if(!err && taxInfo===null) { //Its a new record
        console.log(chalk.red("Tax Information - Its a new record!!"));
        var taxSave = new Accounttaxinformation(req.body);
        taxSave.save().then(taxInfo => {
          res.send({
            message: 'Tax Information Saved !!',
            status: 200,
            data: taxInfo
          })
        }).catch(err => {
          res.send({
            message: 'Tax information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update tax information !!'
        })
      }
  });
}

exports.getTaxInformation = async(req, res, next) => {
  Accounttaxinformation.findOne({'accountObjectId': req.params.id}, async( err, taxInfo) => {
    if (taxInfo!==null) {
       res.send({
         status:200,
         data: taxInfo,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: taxInfo,
        message: 'no record found!!'
      });
    }
  })
};

