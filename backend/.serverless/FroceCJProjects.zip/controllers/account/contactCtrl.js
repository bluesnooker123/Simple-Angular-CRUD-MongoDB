const mongoose = require('mongoose');
const chalk = require('chalk');
require('../../models/contact.js');

const Contact = mongoose.model('Contact');


exports.contactDetails = async(req, res, next) => {
  var result = await req.body.filterResult
  var contactSave = new Contact(result);

  Contact.findOne({'accountObjectId': req.body.accountObjectId}, async( err, contact) => {
     console.log(chalk.blue(contact));
      if (contact!==null) {
        contact.accountObjectId = result.accountObjectId;
        contact.shippingContactDetails = Object.keys(result.shippingContactDetails).length > 0 ? result.shippingContactDetails : contact.shippingContactDetails;
        contact.billingContactDetails = Object.keys(result.billingContactDetails).length > 0 ? result.billingContactDetails : contact.billingContactDetails;
        contact.corporateContactDetails = Object.keys(result.corporateContactDetails).length > 0 ? result.corporateContactDetails : contact.corporateContactDetails;
        contact.save().then(account => {
          res.status(200).send({
            message: 'Updated Done !!'
          })
        }).catch(err => {
          res.status(400).send({
            message: 'Update Failed !!'
          });
        });
      } else if(!err && contact===null) { //Its a new record
        console.log(chalk.red("Its a new record!!"));
        contactSave.save().then(contact => {
          res.status(200).send({
            message: 'Contact Successfully Created!',
          })
        }).catch(err => {
          res.status(400).send({
            message: 'Create Failed!!',
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update contact!!'
        })
      }
  });
}
exports.getAllContacts = async(req, res, next) => {
  Contact.findOne({'accountObjectId': req.params.id}, async( err, contact) => {
    if (contact!==null) {
       res.send({
         status:200,
         data: contact,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: contact,
        message: 'no record found!!'
      });
    }
  })
};
