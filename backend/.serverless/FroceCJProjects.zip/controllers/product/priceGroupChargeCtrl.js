require('../../models/charges.js');

const mongoose = require('mongoose');
const priceGroupCharge = mongoose.model('priceGroupCharge');
const chalk = require('chalk');

exports.chargesGroupOneTime = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Charges Onetime Information Submitted ----------------"));
  console.log(req.body);
  priceGroupCharge.findOne({'productObjectId': req.body.productObjectId, 'pricegroupName': req.body.pricegroupName}, async( err, priceGrpCharge) => {
      if (priceGrpCharge!==null) {
        var isPriceGroupChargeUpdate = false;
        req.body.type = "onetime";
        // Price Group Charges Exist inside the Array then Update
        for(var i=0;i<priceGrpCharge.chargeArray['onetime'].length;i++) {
          if(priceGrpCharge.chargeArray['onetime'][i].name === req.body.name) {
            isPriceGroupChargeUpdate = true;
            priceGrpCharge.chargeArray['onetime'][i].description = req.body.description;
            priceGrpCharge.chargeArray['onetime'][i].chargeAmount = req.body.chargeAmount;
            priceGrpCharge.chargeArray['onetime'][i].chargeDiscount = req.body.chargeDiscount;
            priceGrpCharge.chargeArray['onetime'][i].chargeDiscountAmount = req.body.chargeDiscountAmount;
            priceGrpCharge.chargeArray['onetime'][i].voucher = req.body.voucher;
            priceGrpCharge.chargeArray['onetime'][i].coupon = req.body.coupon;
            priceGrpCharge.chargeArray['onetime'][i].startDate = req.body.startDate;
            priceGrpCharge.chargeArray['onetime'][i].endDate = req.body.endDate;
            priceGrpCharge.chargeArray['onetime'][i].updationdate = new Date();
            break;
          }
        }

        if(!isPriceGroupChargeUpdate)  {
          priceGrpCharge.chargeArray['onetime'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeAmount: req.body.chargeAmount,
            chargeDiscount: req.body.chargeDiscount,
            chargeDiscountAmount: req.body.chargeDiscountAmount,
            voucher: req.body.voucher,
            coupon: req.body.coupon,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
          });
        }

        var priceGrpChargeInformation = new priceGroupCharge(priceGrpCharge);

        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Charges Onetime Information Updated !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });


      } else if(!err && priceGrpCharge===null) { //Its a new record
        console.log(chalk.red("Charges Onetime Information - Its a new record!!"));
        req.body.type = "onetime";
        req.body.chargeArray = {};
        req.body.chargeArray['onetime'] = [];

        req.body.chargeArray['onetime'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeAmount: req.body.chargeAmount,
            chargeDiscount: req.body.chargeDiscount,
            chargeDiscountAmount: req.body.chargeDiscountAmount,
            voucher: req.body.voucher,
            coupon: req.body.coupon,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
        })

        console.log(req.body.chargeArray['onetime']);

        var priceGrpChargeInformation = new priceGroupCharge(req.body);
        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Charges Onetime Information Saved !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Charges Onetime information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update Charges Onetime Information !!'
        })
      }
  });
};

exports.chargesGroupSubscription = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Charges Subscription Information Submitted ----------------"));
  console.log(req.body);
  priceGroupCharge.findOne({'productObjectId': req.body.productObjectId, 'pricegroupName': req.body.pricegroupName}, async( err, priceGrpCharge) => {
      if (priceGrpCharge!==null) {
        var isPriceGroupSubscriptionUpdate = false;
        req.body.type = "subscription";
        // Price Group Charges Exist inside the Array then Update
        for(var i=0;i<priceGrpCharge.chargeArray['subscription'].length;i++) {
          if(priceGrpCharge.chargeArray['subscription'][i].name === req.body.name) {
            isPriceGroupSubscriptionUpdate = true;
            priceGrpCharge.chargeArray['subscription'][i].description = req.body.description;
            priceGrpCharge.chargeArray['subscription'][i].chargeAmount = req.body.chargeAmount;
            priceGrpCharge.chargeArray['subscription'][i].chargeDiscount = req.body.chargeDiscount;
            priceGrpCharge.chargeArray['subscription'][i].chargeDiscountAmount = req.body.chargeDiscountAmount;
            priceGrpCharge.chargeArray['subscription'][i].voucher = req.body.voucher;
            priceGrpCharge.chargeArray['subscription'][i].coupon = req.body.coupon;
            priceGrpCharge.chargeArray['subscription'][i].billingPeriod = req.body.billingPeriod;
            priceGrpCharge.chargeArray['subscription'][i].billingType = req.body.billingType;
            priceGrpCharge.chargeArray['subscription'][i].startDate = req.body.startDate;
            priceGrpCharge.chargeArray['subscription'][i].endDate = req.body.endDate;
            priceGrpCharge.chargeArray['subscription'][i].updationdate = new Date();
            break;
          }
        }

        if(!isPriceGroupSubscriptionUpdate)  {
          priceGrpCharge.chargeArray['subscription'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeAmount: req.body.chargeAmount,
            chargeDiscount: req.body.chargeDiscount,
            chargeDiscountAmount: req.body.chargeDiscountAmount,
            voucher: req.body.voucher,
            coupon: req.body.coupon,
            billingPeriod: req.body.billingPeriod,
            billingType: req.body.billingType,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
          });
        }

        var priceGrpChargeInformation = new priceGroupCharge(priceGrpCharge);

        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Price Group Subscription Information Updated !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });


      } else if(!err && priceGrpCharge===null) { //Its a new record
        console.log(chalk.red("Charges Subscription Information - Its a new record!!"));
        req.body.type = "subscription";
        req.body.chargeArray = {};
        req.body.chargeArray['subscription'] = [];

        req.body.chargeArray['subscription'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeAmount: req.body.chargeAmount,
            chargeDiscount: req.body.chargeDiscount,
            chargeDiscountAmount: req.body.chargeDiscountAmount,
            voucher: req.body.voucher,
            coupon: req.body.coupon,
            billingPeriod: req.body.billingPeriod,
            billingType: req.body.billingType,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
        })

        console.log(req.body.chargeArray['subscription']);

        var priceGrpChargeInformation = new priceGroupCharge(req.body);
        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Charges Subscription Information Saved !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Charges Subscription information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update Charges Subscription Information !!'
        })
      }
  });
};

exports.chargesGroupUsage = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- Charges Usage Information Submitted ----------------"));
  console.log(req.body);
  priceGroupCharge.findOne({'productObjectId': req.body.productObjectId, 'pricegroupName': req.body.pricegroupName}, async( err, priceGrpCharge) => {
      if (priceGrpCharge!==null) {
        var isPriceGroupUsagesUpdate = false;
        req.body.type = "usages";
        // Price Group Charges Exist inside the Array then Update
        for(var i=0;i<priceGrpCharge.chargeArray['usages'].length;i++) {
          if(priceGrpCharge.chargeArray['usages'][i].name === req.body.name) {
            isPriceGroupUsagesUpdate = true;
            priceGrpCharge.chargeArray['usages'][i].description = req.body.description;
            priceGrpCharge.chargeArray['usages'][i].chargeRate = req.body.chargeRate;
            priceGrpCharge.chargeArray['usages'][i].startDate = req.body.startDate;
            priceGrpCharge.chargeArray['usages'][i].endDate = req.body.endDate;
            priceGrpCharge.chargeArray['usages'][i].updationdate = new Date();
            break;
          }
        }

        if(!isPriceGroupUsagesUpdate)  {
          priceGrpCharge.chargeArray['usages'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeRate: req.body.chargeRate,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
          });
        }

        var priceGrpChargeInformation = new priceGroupCharge(priceGrpCharge);

        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Charges Usages Information Updated !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });


      } else if(!err && priceGrpCharge===null) { //Its a new record
        console.log(chalk.red("Charges Usages Information - Its a new record!!"));
        req.body.type = "usages";
        req.body.chargeArray = {};
        req.body.chargeArray['usages'] = [];

        req.body.chargeArray['usages'].push({
            name: req.body.name,
            description: req.body.description,
            type: req.body.type,
            chargeRate: req.body.chargeRate,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            creationdate: new Date(),
            updationdate: new Date(),
        })

        console.log(req.body.chargeArray['subscription']);

        var priceGrpChargeInformation = new priceGroupCharge(req.body);
        priceGrpChargeInformation.save().then(priceGrpCharge => {
          res.send({
            message: 'Charges Usages Information Saved !!',
            status: 200,
            data: priceGrpCharge
          })
        }).catch(err => {
          res.send({
            message: 'Charges Usages information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update Charges Usages Information !!'
        })
      }
  });
};


exports.getPriceGroupChargesInformation = async(req, res, next) => {
  priceGroupCharge.findOne({'productObjectId': req.body.productObjectId, 'pricegroupName': req.body.pricegroupName}, async( err, priceGrpCharge) => {
    if (priceGrpCharge!==null) {
       res.send({
         status:200,
         data: priceGrpCharge,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: priceGrpCharge,
        message: 'no record found!!'
      });
    }
  })
};
