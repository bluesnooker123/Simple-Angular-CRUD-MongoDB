const mongoose = require('mongoose');
const Product = mongoose.model('Product');
const chalk = require('chalk');
const config = require('config');

var bucketName = config.AWS.bucket;
var AWS = require('aws-sdk');
// var s3Bucket = new AWS.S3( { params: {Bucket: 'forcecj-products-pix'} } );
var s3Bucket = new AWS.S3();



require('../../models/product.js');

AWS.config.update({
  accessKeyId: config.AWS.accessKeyId,
  secretAccessKey: config.AWS.secretAccessKey,
  region: config.AWS.region
});

// Product Image upload
exports.imageCreate = (req, res, next) => {
    var buf = Buffer.from(req.body.imageBase64.replace(/^data:image\/\w+;base64,/, ""),'base64');
    var data = {
      Key: req.body.filename, // type is not required
      Body: buf,
      Bucket: bucketName,
      ContentEncoding: 'base64',
      ContentType: 'image/jpeg'
    };

    s3Bucket.upload(data, function(err, data){
        if (err) {
          console.log(err);
          console.log(chalk.red('Error uploading data: ', data));
          res.json({
            status: 400,
            message: 'Error uploading data!'
          })
        } else {
          console.log(chalk.green('succesfully uploaded the image!'));
          res.json({
            status: 200,
            data: data.Location,
            message: 'done'
          })
        }
    });
};

// Product Create
exports.ProductCreate = (req, res, next) => {
  var product = new Product(req.body);
  product.save()
    .then(product => {
      res.status(200).json({
        'message': 'Added Successfully',
        'productId': product._id
      });
    })
    .catch(err => {
      res.status(400).send('Failed to create new record');
    });
};

//Product Update
exports.productUpdate = (req, res, next) => {
  Product.findById(req.params.id, ( err, product) => {
    if (!product)
      return onErrorResumeNext(new Error('Could not load document'));
    else  {
      // product.productName = req.body.productName;
      product.version = req.body.version;
      product.type = req.body.type;
      product.subtype = req.body.subtype;
      product.sku = req.body.sku;
      product.imageLocation = req.body.imageLocation;
      product.description = req.body.description;
      product.taxCode = req.body.taxCode;
      product.taxMode = req.body.taxMode;
      product.startDate = req.body.startDate;
      product.endDate = req.body.endDate;
      product.updationdate = new Date();
      product.save().then(product => {
          res.json('Update Done')
      }).catch(err => {
          res.status(400).send('Update Failed');
      });
    }
  });
};

// Product List
exports.productList = (req, res, next) => {
  Product.find((err,product)=> {
    if (err)
       console.log(err)
    else
      res.status(200).json(product);
  });
}

// Product List By Id
exports.productListById = (req, res, next) => {
  Product.findById(req.params.id, (err, product) => {
    if (err)
      console.log(err)
    else
      res.json(product);
  });
}

// Product Delete By Id
exports.productDeleteById = (req, res, next) => {
  Product.findByIdAndRemove({_id: req.params.id}, (err, product) => {
    if (err)
      res.json(err);
    else
      res.json('Remove sucessfully');
  });
}

