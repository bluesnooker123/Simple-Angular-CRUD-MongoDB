require('../../models/pricegroup.js');
require('../../models/charges.js');


const mongoose = require('mongoose');
const Pricegroup = mongoose.model('Pricegroup');
const priceGroupCharge = mongoose.model('priceGroupCharge');
const chalk = require('chalk');



exports.priceGroup = async(req, res, next) => {
  console.log(chalk.bgYellowBright("---------------- PriceGroup Information Submitted ----------------"));
  console.log(req.body);
  Pricegroup.findOne({'productObjectId': req.body.productObjectId}, async( err, priceGrp) => {
      if (priceGrp!==null) {
        var isPriceGroupUpdate = false;
        priceGrp.name = req.body.name;
        priceGrp.startDate = req.body.startDate;
        priceGrp.endDate = req.body.endDate;
        priceGrp.description  = req.body.description;
        priceGrp.enableCharge = req.body.enableCharge;
        priceGrp.version = req.body.version;
        priceGrp.updationdate = new Date();


        // Price Group Exist inside the Array then Update
        for(var i=0;i<priceGrp.priceGroup.length;i++) {
          if(priceGrp.priceGroup[i].name === req.body.name) {
            isPriceGroupUpdate = true;
            priceGrp.priceGroup[i].startDate = req.body.startDate;
            priceGrp.priceGroup[i].endDate = req.body.endDate;
            priceGrp.priceGroup[i].description = req.body.description;
            priceGrp.priceGroup[i].enableCharge = req.body.enableCharge;
            priceGrp.priceGroup[i].version = req.body.version;
            priceGrp.priceGroup[i].creationdate = req.body.creationdate;
            priceGrp.priceGroup[i].updationdate = new Date();
            break;
          }
        }

        // Price Group Exist inside the Array then Update

        if(!isPriceGroupUpdate)  {
          priceGrp.priceGroup.push({
            name: req.body.name,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            description: req.body.description,
            enableCharge: req.body.enableCharge,
            version: req.body.version,
            creationdate: req.body.creationdate,
            updationdate: new Date(),
          });
        }

        var priceGrpInformation = new Pricegroup(priceGrp);

        priceGrpInformation.save().then(priceGrp => {
          res.send({
            message: 'Price Group Information Updated !!',
            status: 200,
            data: priceGrp
          })
        }).catch(err => {
          res.send({
            message: 'Update Failed !!',
            status: 400,
            err: err
          });
        });
      } else if(!err && priceGrp===null) { //Its a new record
        console.log(chalk.red("PriceGroup Information - Its a new record!!"));
        req.body.priceGroup = [];
        if(req.body.version === null) {
          req.body.version = 1;
        }
        req.body.priceGroup.push({
          name: req.body.name,
          startDate: req.body.startDate,
          endDate: req.body.endDate,
          description: req.body.description,
          enableCharge: req.body.enableCharge,
          version: req.body.version,
          creationdate: req.body.creationdate,
          updationdate: new Date(),
        });

        // Insert into charge table as well -
        // req.body.pricegroupName = req.body.name;
        // var priceGrpChargeInformation = new priceGroupCharge(req.body);
        // priceGrpChargeInformation.save().then(priceGrpCharge => {
        //   console.log(chalk.green('keep track in price group charge!'))
        // }).catch(err => {
        //   console.log(chalk.red('Not able to make track in price group charge!'))
        // });

        var priceGrpInfo = new Pricegroup(req.body);
        priceGrpInfo.save().then(priceGrpdata => {
          res.send({
            message: 'PriceGroup Information Saved !!',
            status: 200,
            data: priceGrpdata
          })
        }).catch(err => {
          res.send({
            message: 'PriceGroup information, Save Failed !!',
            status: 400,
            err: err
          });
        });
      } else {
        res.send({
          status: 404,
          message: 'Error, Not able to update PriceGroup Information !!'
        })
      }
  });
}

exports.getPriceGroupInformation = async(req, res, next) => {
  Pricegroup.findOne({'productObjectId': req.params.id}, async( err, priceGrpdata) => {
    if (priceGrpdata!==null) {
       res.send({
         status:200,
         data: priceGrpdata,
         message: 'successfully fetched record !!'
       });
    } else {
      res.send({
        status:200,
        data: priceGrpdata,
        message: 'no record found!!'
      });
    }
  })
};

